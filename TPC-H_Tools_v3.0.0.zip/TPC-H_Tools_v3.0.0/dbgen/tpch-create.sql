create table lineitem (
	l_orderkey int,
	l_partkey int,
	l_suppkey int,
	l_linenumber int,
	l_quantity double,
	l_extendedprice double,
	l_discount double,
	l_tax double,
	l_returnflag char(1),
	l_linestatus char(1),
	l_shipdate date,
	l_commitdate date,
	l_receiptdate date,
	l_shipinstruct char(25),
	l_shipmode char(10),
	l_comment char(44)
);

create table orders (
	o_orderkey int,
	o_custkey int,
	o_orderstatus char(1),
	o_totalprice double,
	o_orderdate date,
	o_orderpriority char(15),
	o_clerk char(15),
	o_shippriority integer,
	o_comment char(79)
);

create table customer (
	c_custkey integer,
	c_name char(25),
	c_address char(40),
	c_nationkey int,
	c_phone char(15),
	c_acctbal double,
	c_mktsegment char(10),
	c_comment char(117)
);

create table region (
	r_regionkey int,
	r_name char(55),
	r_comment char (152)
);

create table nation (
	n_nationkey int,
	n_name char(25),
	n_regionkey int,
	n_comment char(152)
);

create table partsupp (
	ps_partkey int,
	ps_suppkey int,
	ps_availqty int,
	ps_supplycost double,
	comment char(199)
);

create table part (
	p_partkey int,
	p_name char(55),
	p_mfgr char(25),
	p_brand char(10),
	p_type char(25),
	p_type int,
	p_container char(10),
	p_retailprice double,
	p_comment char(23)
);

create table supplier (
	s_suppkey int,
	s_name char(25),
	s_address char(40),
	s_nationkey int,
	s_phone char(15),
	s_acctbal double,
	s_comment char(101)
);
